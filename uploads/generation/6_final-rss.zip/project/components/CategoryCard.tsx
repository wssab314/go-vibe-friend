import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { ContentCategory } from '@/types';
import { 
  Trophy, 
  TrendingUp, 
  Music, 
  Smartphone, 
  Heart,
  Check,
  Plus
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

interface CategoryCardProps {
  category: ContentCategory;
  onPress: () => void;
  viewMode?: 'list' | 'grid';
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ 
  category, 
  onPress, 
  viewMode = 'list' 
}) => {
  const { theme } = useTheme();

  const getIcon = () => {
    const iconProps = {
      size: viewMode === 'grid' ? 20 : 24,
      color: category.subscribed ? theme.primary : theme.textSecondary,
      strokeWidth: 2.5,
    };

    switch (category.icon) {
      case 'trophy':
        return <Trophy {...iconProps} />;
      case 'trending-up':
        return <TrendingUp {...iconProps} />;
      case 'music':
        return <Music {...iconProps} />;
      case 'smartphone':
        return <Smartphone {...iconProps} />;
      case 'heart':
        return <Heart {...iconProps} />;
      default:
        return <Heart {...iconProps} />;
    }
  };

  const getSubscriberCount = () => {
    // Mock subscriber counts for demonstration
    const counts = {
      'sports': '2.4K',
      'finance': '1.8K',
      'arts': '3.2K',
      'technology': '4.1K',
      'lifestyle': '2.9K',
    };
    return counts[category.id] || '1.2K';
  };

  if (viewMode === 'grid') {
    return (
      <TouchableOpacity
        style={[
          styles.gridContainer,
          {
            backgroundColor: theme.surface,
            borderColor: category.subscribed ? theme.primary : theme.border,
          },
        ]}
        onPress={onPress}
        activeOpacity={0.8}
      >
        <View style={styles.gridHeader}>
          <View style={[
            styles.gridIconContainer,
            { backgroundColor: category.subscribed ? `${theme.primary}15` : `${theme.textSecondary}10` }
          ]}>
            {getIcon()}
          </View>
          <View style={[
            styles.subscribeIconContainer,
            { backgroundColor: category.subscribed ? theme.primary : theme.border }
          ]}>
            {category.subscribed ? (
              <Check size={12} color={theme.background} strokeWidth={3} />
            ) : (
              <Plus size={12} color={theme.textSecondary} strokeWidth={2.5} />
            )}
          </View>
        </View>
        
        <Text style={[styles.gridTitle, { color: theme.text }]} numberOfLines={2}>
          {category.name}
        </Text>
        
        <Text style={[styles.gridDescription, { color: theme.textSecondary }]} numberOfLines={2}>
          {category.description}
        </Text>
        
        <View style={styles.gridFooter}>
          <Text style={[styles.subscriberCount, { color: theme.textSecondary }]}>
            {getSubscriberCount()} followers
          </Text>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      style={[
        styles.listContainer,
        {
          backgroundColor: theme.surface,
          borderColor: category.subscribed ? theme.primary : theme.border,
        },
      ]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={styles.listContent}>
        <View style={styles.listLeft}>
          <View style={[
            styles.listIconContainer,
            { backgroundColor: category.subscribed ? `${theme.primary}15` : `${theme.textSecondary}10` }
          ]}>
            {getIcon()}
          </View>
          
          <View style={styles.listInfo}>
            <Text style={[styles.listTitle, { color: theme.text }]}>
              {category.name}
            </Text>
            <Text style={[styles.listDescription, { color: theme.textSecondary }]}>
              {category.description}
            </Text>
            <View style={styles.listMeta}>
              <Text style={[styles.subscriberCount, { color: theme.textSecondary }]}>
                {getSubscriberCount()} followers
              </Text>
              {category.subscribed && (
                <>
                  <View style={[styles.metaDot, { backgroundColor: theme.textSecondary }]} />
                  <Text style={[styles.subscribedText, { color: theme.primary }]}>
                    Subscribed
                  </Text>
                </>
              )}
            </View>
          </View>
        </View>
        
        <View style={[
          styles.subscribeButton,
          {
            backgroundColor: category.subscribed ? theme.primary : 'transparent',
            borderColor: theme.primary,
          },
        ]}>
          {category.subscribed ? (
            <Check size={16} color={theme.background} strokeWidth={2.5} />
          ) : (
            <Plus size={16} color={theme.primary} strokeWidth={2.5} />
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  // List View Styles
  listContainer: {
    borderRadius: 20,
    borderWidth: 1.5,
    marginBottom: 12,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 6,
  },
  listContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
  },
  listLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  listIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  listInfo: {
    flex: 1,
  },
  listTitle: {
    fontSize: 17,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
    letterSpacing: -0.2,
  },
  listDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginBottom: 6,
    letterSpacing: 0.1,
  },
  listMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  subscriberCount: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    letterSpacing: 0.2,
  },
  metaDot: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    marginHorizontal: 8,
  },
  subscribedText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    letterSpacing: 0.2,
  },
  subscribeButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
  },

  // Grid View Styles
  gridContainer: {
    borderRadius: 20,
    borderWidth: 1.5,
    padding: 20,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 6,
    minHeight: 160,
  },
  gridHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  gridIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  subscribeIconContainer: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  gridTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    marginBottom: 8,
    letterSpacing: -0.2,
    lineHeight: 22,
  },
  gridDescription: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    marginBottom: 12,
    letterSpacing: 0.1,
    lineHeight: 18,
    flex: 1,
  },
  gridFooter: {
    marginTop: 'auto',
  },
});