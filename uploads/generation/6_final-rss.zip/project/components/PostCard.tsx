import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, Animated } from 'react-native';
import { Heart, MessageCircle, Repeat2, Share, MoveHorizontal as MoreHorizontal } from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { useContent } from '@/contexts/ContentContext';
import { Post } from '@/types';

interface PostCardProps {
  post: Post;
  onPress: () => void;
  showFullContent?: boolean;
}

export const PostCard: React.FC<PostCardProps> = ({ 
  post, 
  onPress, 
  showFullContent = false 
}) => {
  const { theme } = useTheme();
  const { toggleLike, toggleSave } = useContent();

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'now';
    if (diffInHours < 24) return `${diffInHours}h`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d`;
    
    const diffInWeeks = Math.floor(diffInDays / 7);
    return `${diffInWeeks}w`;
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const ActionButton = ({ 
    onPress, 
    icon, 
    count, 
    color = theme.textSecondary, 
    activeColor, 
    isActive = false,
    hoverColor = 'rgba(29, 155, 240, 0.08)'
  }: {
    onPress: () => void;
    icon: React.ReactNode;
    count?: string | number;
    color?: string;
    activeColor?: string;
    isActive?: boolean;
    hoverColor?: string;
  }) => {
    const [isPressed, setIsPressed] = React.useState(false);
    
    return (
      <TouchableOpacity 
        style={styles.actionButton}
        onPress={onPress}
        onPressIn={() => setIsPressed(true)}
        onPressOut={() => setIsPressed(false)}
        activeOpacity={0.9}
      >
        <View style={[
          styles.actionIconContainer,
          isPressed && { backgroundColor: hoverColor },
          isActive && activeColor && { backgroundColor: `${activeColor}12` }
        ]}>
          {icon}
        </View>
        {count !== undefined && (
          <Text style={[
            styles.actionText, 
            { color: isActive && activeColor ? activeColor : color }
          ]}>
            {typeof count === 'number' ? formatNumber(count) : count}
          </Text>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <TouchableOpacity 
      style={[styles.container, { borderBottomColor: theme.border }]}
      onPress={onPress}
      activeOpacity={0.98}
    >
      <View style={styles.avatarContainer}>
        <Image 
          source={{ uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=48&h=48&dpr=2' }}
          style={styles.avatar}
        />
      </View>

      <View style={styles.contentContainer}>
        <View style={styles.header}>
          <View style={styles.userInfo}>
            <Text style={[styles.displayName, { color: theme.text }]}>
              {post.author}
            </Text>
            <Text style={[styles.username, { color: theme.textSecondary }]}>
              @{post.author.toLowerCase().replace(' ', '')}
            </Text>
            <View style={[styles.dot, { backgroundColor: theme.textSecondary }]} />
            <Text style={[styles.timestamp, { color: theme.textSecondary }]}>
              {formatTimeAgo(post.createdAt)}
            </Text>
          </View>
          <TouchableOpacity style={styles.moreButton} activeOpacity={0.7}>
            <MoreHorizontal size={18} color={theme.textSecondary} />
          </TouchableOpacity>
        </View>

        <Text style={[styles.content, { color: theme.text }]}>
          {showFullContent ? post.content : post.preview}
        </Text>

        <View style={styles.actions}>
          <ActionButton
            onPress={(e) => {
              e?.stopPropagation?.();
              // Handle comment action
            }}
            icon={<MessageCircle size={16} color={theme.textSecondary} />}
            count={12}
            hoverColor="rgba(29, 155, 240, 0.08)"
          />

          <ActionButton
            onPress={(e) => {
              e?.stopPropagation?.();
              // Handle repost action
            }}
            icon={<Repeat2 size={16} color={theme.textSecondary} />}
            count={3}
            hoverColor="rgba(0, 186, 124, 0.08)"
          />

          <ActionButton
            onPress={(e) => {
              e?.stopPropagation?.();
              toggleLike(post.id);
            }}
            icon={
              <Heart 
                size={16} 
                color={post.isLiked ? '#F91880' : theme.textSecondary}
                fill={post.isLiked ? '#F91880' : 'none'}
              />
            }
            count={post.likes}
            isActive={post.isLiked}
            activeColor="#F91880"
            hoverColor="rgba(249, 24, 128, 0.08)"
          />

          <View style={styles.rightActions}>
            <ActionButton
              onPress={(e) => {
                e?.stopPropagation?.();
                toggleSave(post.id);
              }}
              icon={
                <View style={[
                  styles.bookmarkIcon,
                  { borderColor: post.isSaved ? theme.primary : theme.textSecondary }
                ]}>
                  {post.isSaved && (
                    <View style={[styles.bookmarkFill, { backgroundColor: theme.primary }]} />
                  )}
                </View>
              }
              isActive={post.isSaved}
              activeColor={theme.primary}
              hoverColor="rgba(29, 155, 240, 0.08)"
            />

            <ActionButton
              onPress={(e) => {
                e?.stopPropagation?.();
                // Handle share action
              }}
              icon={<Share size={16} color={theme.textSecondary} />}
              hoverColor="rgba(29, 155, 240, 0.08)"
            />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 0.5,
    backgroundColor: 'transparent',
  },
  avatarContainer: {
    marginRight: 14,
    paddingTop: 2,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  contentContainer: {
    flex: 1,
    minWidth: 0,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    minWidth: 0,
  },
  displayName: {
    fontSize: 15,
    fontFamily: 'Inter-Bold',
    marginRight: 6,
    flexShrink: 0,
  },
  username: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    marginRight: 6,
    flexShrink: 1,
  },
  dot: {
    width: 2,
    height: 2,
    borderRadius: 1,
    marginRight: 6,
    flexShrink: 0,
  },
  timestamp: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    flexShrink: 0,
  },
  moreButton: {
    padding: 8,
    borderRadius: 20,
    marginRight: -8,
  },
  content: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    lineHeight: 22,
    marginBottom: 14,
    letterSpacing: 0.2,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    maxWidth: 450,
    marginTop: 2,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: 64,
  },
  actionIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 6,
    transition: 'backgroundColor 0.15s ease',
  },
  actionText: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    minWidth: 20,
    textAlign: 'left',
    letterSpacing: 0.1,
  },
  rightActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  bookmarkIcon: {
    width: 14,
    height: 16,
    borderWidth: 1.5,
    borderTopWidth: 0,
    borderRadius: 2,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
    position: 'relative',
  },
  bookmarkFill: {
    position: 'absolute',
    top: 0,
    left: -1.5,
    right: -1.5,
    bottom: -1.5,
    borderRadius: 2,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
  },
});