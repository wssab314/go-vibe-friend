export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  subscriptions: string[];
  createdAt: Date;
}

export interface ContentCategory {
  id: string;
  name: string;
  icon: string;
  description: string;
  subscribed: boolean;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  preview: string;
  author: string;
  category: string;
  createdAt: Date;
  likes: number;
  isLiked: boolean;
  isSaved: boolean;
  readTime: string;
}

export interface Comment {
  id: string;
  postId: string;
  author: string;
  content: string;
  createdAt: Date;
}

export interface Theme {
  background: string;
  surface: string;
  text: string;
  textSecondary: string;
  border: string;
  primary: string;
  secondary: string;
  accent: string;
  success: string;
  warning: string;
  error: string;
}