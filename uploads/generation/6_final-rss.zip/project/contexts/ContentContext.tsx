import React, { createContext, useContext, useState, useEffect } from 'react';
import { ContentCategory, Post, Comment } from '@/types';

interface ContentContextType {
  categories: ContentCategory[];
  posts: Post[];
  savedPosts: Post[];
  isLoading: boolean;
  toggleSubscription: (categoryId: string) => void;
  toggleLike: (postId: string) => void;
  toggleSave: (postId: string) => void;
  addComment: (postId: string, content: string) => void;
  refreshFeed: () => Promise<void>;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

const mockCategories: ContentCategory[] = [
  { id: 'sports', name: 'Sports', icon: 'trophy', description: 'Basketball, Football, Tennis', subscribed: false },
  { id: 'finance', name: 'Finance & Economy', icon: 'trending-up', description: 'Market trends, Investment tips', subscribed: false },
  { id: 'arts', name: 'Arts & Entertainment', icon: 'music', description: 'Dance, Music, Theater', subscribed: false },
  { id: 'technology', name: 'Technology', icon: 'smartphone', description: 'AI, Programming, Gadgets', subscribed: false },
  { id: 'lifestyle', name: 'Lifestyle', icon: 'heart', description: 'Health, Travel, Food', subscribed: false },
];

const mockPosts: Post[] = [
  {
    id: '1',
    title: 'The Future of Basketball Analytics',
    content: 'Basketball analytics have revolutionized how we understand the game. From tracking player movements to predicting game outcomes, data science is changing basketball forever. Teams now use advanced metrics to make strategic decisions, draft players, and optimize performance. The integration of machine learning algorithms allows coaches to analyze patterns that were previously invisible to the human eye.',
    preview: 'Basketball analytics have revolutionized how we understand the game. From tracking player movements to predicting outcomes...',
    author: 'Mike Johnson',
    category: 'sports',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    likes: 156,
    isLiked: false,
    isSaved: false,
    readTime: '3 min read',
  },
  {
    id: '2',
    title: 'Market Volatility in 2024',
    content: 'The financial markets have shown unprecedented volatility this year. Various factors including geopolitical tensions, inflation concerns, and technological disruptions have created a perfect storm for market uncertainty. Investors are advised to diversify their portfolios and consider long-term strategies rather than attempting to time the market.',
    preview: 'The financial markets have shown unprecedented volatility this year. Various factors including geopolitical tensions...',
    author: 'Sarah Wilson',
    category: 'finance',
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    likes: 89,
    isLiked: false,
    isSaved: false,
    readTime: '2 min read',
  },
  {
    id: '3',
    title: 'AI in Creative Arts',
    content: 'Artificial intelligence is transforming the creative landscape in ways we never imagined. From AI-generated music to digital art creation, machines are becoming creative partners rather than replacements. Artists are embracing these tools to push boundaries and explore new forms of expression. The debate continues about authenticity, but the possibilities are endless.',
    preview: 'Artificial intelligence is transforming the creative landscape in ways we never imagined. From AI-generated music...',
    author: 'David Chen',
    category: 'arts',
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    likes: 234,
    isLiked: true,
    isSaved: false,
    readTime: '4 min read',
  },
  {
    id: '4',
    title: 'Revolutionary Mobile Apps',
    content: 'The mobile app ecosystem continues to evolve at breakneck speed. New frameworks, development tools, and user interface paradigms are emerging constantly. React Native, Flutter, and native development each offer unique advantages. The key is choosing the right tool for your specific project requirements and team expertise.',
    preview: 'The mobile app ecosystem continues to evolve at breakneck speed. New frameworks, development tools, and UI paradigms...',
    author: 'Emma Rodriguez',
    category: 'technology',
    createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
    likes: 312,
    isLiked: false,
    isSaved: true,
    readTime: '5 min read',
  },
  {
    id: '5',
    title: 'Mindful Living in Digital Age',
    content: 'Finding balance in our hyperconnected world has become more challenging than ever. Digital wellness isn\'t just about screen time; it\'s about creating intentional relationships with technology. Mindfulness practices, digital detoxes, and conscious consumption of information can help us maintain mental clarity and emotional well-being.',
    preview: 'Finding balance in our hyperconnected world has become more challenging than ever. Digital wellness isn\'t just about...',
    author: 'Alex Thompson',
    category: 'lifestyle',
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    likes: 445,
    isLiked: false,
    isSaved: false,
    readTime: '3 min read',
  },
];

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [categories, setCategories] = useState<ContentCategory[]>(mockCategories);
  const [posts, setPosts] = useState<Post[]>(mockPosts);
  const [savedPosts, setSavedPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const toggleSubscription = (categoryId: string) => {
    setCategories(prev => 
      prev.map(cat => 
        cat.id === categoryId 
          ? { ...cat, subscribed: !cat.subscribed }
          : cat
      )
    );
  };

  const toggleLike = (postId: string) => {
    setPosts(prev => 
      prev.map(post => 
        post.id === postId 
          ? { 
              ...post, 
              isLiked: !post.isLiked,
              likes: post.isLiked ? post.likes - 1 : post.likes + 1
            }
          : post
      )
    );
  };

  const toggleSave = (postId: string) => {
    setPosts(prev => 
      prev.map(post => 
        post.id === postId 
          ? { ...post, isSaved: !post.isSaved }
          : post
      )
    );

    const post = posts.find(p => p.id === postId);
    if (post) {
      if (post.isSaved) {
        setSavedPosts(prev => prev.filter(p => p.id !== postId));
      } else {
        setSavedPosts(prev => [...prev, { ...post, isSaved: true }]);
      }
    }
  };

  const addComment = (postId: string, content: string) => {
    // Implementation for adding comments
    console.log(`Adding comment to post ${postId}: ${content}`);
  };

  const refreshFeed = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
  };

  useEffect(() => {
    setSavedPosts(posts.filter(post => post.isSaved));
  }, [posts]);

  return (
    <ContentContext.Provider value={{
      categories,
      posts,
      savedPosts,
      isLoading,
      toggleSubscription,
      toggleLike,
      toggleSave,
      addComment,
      refreshFeed,
    }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};