import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, Dimensions, Animated } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { Button } from '@/components/Button';
import { BookOpen, Sparkles, TrendingUp, Users } from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

export default function WelcomeScreen() {
  const { theme } = useTheme();
  const router = useRouter();
  const fadeAnim = React.useRef(new Animated.Value(0)).current;
  const slideAnim = React.useRef(new Animated.Value(50)).current;

  React.useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Background Elements */}
      <View style={[styles.backgroundPattern, { opacity: theme.isDark ? 0.03 : 0.05 }]}>
        <View style={[styles.circle, styles.circle1, { backgroundColor: theme.primary }]} />
        <View style={[styles.circle, styles.circle2, { backgroundColor: theme.secondary }]} />
        <View style={[styles.circle, styles.circle3, { backgroundColor: theme.accent }]} />
      </View>

      <Animated.View 
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        {/* Hero Section */}
        <View style={styles.heroSection}>
          <View style={[styles.logoContainer, { backgroundColor: `${theme.primary}15` }]}>
            <BookOpen size={32} color={theme.primary} strokeWidth={2.5} />
            <View style={[styles.sparkle, styles.sparkle1]}>
              <Sparkles size={12} color={theme.accent} />
            </View>
            <View style={[styles.sparkle, styles.sparkle2]}>
              <Sparkles size={8} color={theme.secondary} />
            </View>
          </View>
          
          <Text style={[styles.title, { color: theme.text }]}>
            ContentFlow
          </Text>
          
          <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
            Discover, curate, and engage with{'\n'}
            <Text style={{ color: theme.primary, fontFamily: 'Inter-SemiBold' }}>
              premium content
            </Text>{' '}
            from your favorite topics
          </Text>
        </View>

        {/* Features Preview */}
        <View style={styles.featuresContainer}>
          <View style={[styles.featureItem, { backgroundColor: theme.surface }]}>
            <TrendingUp size={20} color={theme.primary} />
            <Text style={[styles.featureText, { color: theme.text }]}>
              Trending Topics
            </Text>
          </View>
          
          <View style={[styles.featureItem, { backgroundColor: theme.surface }]}>
            <Users size={20} color={theme.secondary} />
            <Text style={[styles.featureText, { color: theme.text }]}>
              Expert Authors
            </Text>
          </View>
          
          <View style={[styles.featureItem, { backgroundColor: theme.surface }]}>
            <BookOpen size={20} color={theme.accent} />
            <Text style={[styles.featureText, { color: theme.text }]}>
              Curated Feed
            </Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          <Button
            title="Get Started"
            onPress={() => router.push('/(auth)/sign-up')}
            style={[styles.primaryButton, { backgroundColor: theme.primary }]}
            textStyle={styles.primaryButtonText}
          />
          
          <Button
            title="Sign In"
            onPress={() => router.push('/(auth)/sign-in')}
            variant="outline"
            style={[styles.secondaryButton, { borderColor: theme.border }]}
            textStyle={[styles.secondaryButtonText, { color: theme.text }]}
          />
        </View>
        
        {/* Trust Indicators */}
        <View style={styles.trustSection}>
          <Text style={[styles.trustText, { color: theme.textSecondary }]}>
            Trusted by 10,000+ content enthusiasts
          </Text>
          <View style={styles.trustDots}>
            {[...Array(5)].map((_, i) => (
              <View 
                key={i} 
                style={[
                  styles.trustDot, 
                  { backgroundColor: i < 3 ? theme.primary : theme.border }
                ]} 
              />
            ))}
          </View>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
  },
  backgroundPattern: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    overflow: 'hidden',
  },
  circle: {
    position: 'absolute',
    borderRadius: 999,
  },
  circle1: {
    width: width * 0.8,
    height: width * 0.8,
    top: -width * 0.4,
    right: -width * 0.3,
  },
  circle2: {
    width: width * 0.6,
    height: width * 0.6,
    bottom: -width * 0.2,
    left: -width * 0.2,
  },
  circle3: {
    width: width * 0.4,
    height: width * 0.4,
    top: height * 0.3,
    right: -width * 0.1,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: 28,
    paddingTop: height * 0.12,
    paddingBottom: 40,
    zIndex: 1,
  },
  heroSection: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    marginTop: -60,
  },
  logoContainer: {
    width: 80,
    height: 80,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
    position: 'relative',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 12,
  },
  sparkle: {
    position: 'absolute',
  },
  sparkle1: {
    top: -4,
    right: -4,
  },
  sparkle2: {
    bottom: 8,
    left: -2,
  },
  title: {
    fontSize: 36,
    fontFamily: 'Poppins-Bold',
    marginBottom: 16,
    letterSpacing: -1,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 17,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 26,
    letterSpacing: 0.2,
    paddingHorizontal: 20,
  },
  featuresContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 40,
    paddingHorizontal: 8,
  },
  featureItem: {
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderRadius: 16,
    flex: 1,
    marginHorizontal: 4,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  featureText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    marginTop: 8,
    textAlign: 'center',
    letterSpacing: 0.3,
  },
  actionsContainer: {
    gap: 16,
  },
  primaryButton: {
    paddingVertical: 18,
    borderRadius: 16,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  primaryButtonText: {
    fontSize: 17,
    fontFamily: 'Inter-Bold',
    letterSpacing: 0.5,
  },
  secondaryButton: {
    paddingVertical: 18,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  secondaryButtonText: {
    fontSize: 17,
    fontFamily: 'Inter-SemiBold',
    letterSpacing: 0.3,
  },
  trustSection: {
    alignItems: 'center',
    marginTop: 32,
  },
  trustText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginBottom: 8,
    letterSpacing: 0.2,
  },
  trustDots: {
    flexDirection: 'row',
    gap: 6,
  },
  trustDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
});