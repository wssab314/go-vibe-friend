import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Image, ScrollView, Animated, Dimensions, Modal, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { useContent } from '@/contexts/ContentContext';
import { TextInput } from '@/components/TextInput';
import { Button } from '@/components/Button';
import { Settings, Moon, Sun, Bookmark, History, Bell, LogOut, ChevronRight, CreditCard as Edit3, Award, TrendingUp, Users, Eye, Heart, Share2, Crown, Zap } from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function ProfileScreen() {
  const { theme, isDark, toggleTheme } = useTheme();
  const { user, signOut, updateUser } = useAuth();
  const { categories, savedPosts } = useContent();
  const router = useRouter();
  const [scrollY] = useState(new Animated.Value(0));
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
  });
  const [isUpdating, setIsUpdating] = useState(false);

  const subscribedCategories = categories.filter(cat => cat.subscribed);

  const handleSignOut = async () => {
    await signOut();
  };

  const handleEditProfile = () => {
    setEditForm({
      name: user?.name || '',
      email: user?.email || '',
    });
    setIsEditModalVisible(true);
  };

  const handleSaveProfile = async () => {
    if (!editForm.name.trim()) {
      Alert.alert('Error', 'Name is required');
      return;
    }

    if (!editForm.email.trim() || !/\S+@\S+\.\S+/.test(editForm.email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    setIsUpdating(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      updateUser({
        name: editForm.name.trim(),
        email: editForm.email.trim(),
      });
      
      setIsEditModalVisible(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to update profile. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  // Profile stats data
  const profileStats = [
    { label: 'Articles Read', value: '156', icon: Eye, color: theme.primary },
    { label: 'Subscriptions', value: subscribedCategories.length.toString(), icon: Users, color: theme.secondary },
    { label: 'Saved Posts', value: savedPosts.length.toString(), icon: Bookmark, color: theme.accent },
    { label: 'Engagement', value: '2.4K', icon: Heart, color: '#F91880' },
  ];

  // Achievement badges
  const achievements = [
    { id: 1, title: 'Early Adopter', icon: Crown, color: '#FFD700', earned: true },
    { id: 2, title: 'Content Explorer', icon: TrendingUp, color: theme.primary, earned: true },
    { id: 3, title: 'Community Builder', icon: Users, color: theme.secondary, earned: false },
    { id: 4, title: 'Power Reader', icon: Zap, color: theme.accent, earned: true },
  ];

  const MenuSection = ({ title, children, style = {} }) => (
    <View style={[styles.menuSection, style]}>
      <Text style={[styles.menuSectionTitle, { color: theme.text }]}>
        {title}
      </Text>
      <View style={[styles.menuSectionContent, { backgroundColor: theme.surface }]}>
        {children}
      </View>
    </View>
  );

  const MenuItem = ({ icon, title, onPress, rightText, rightComponent, isLast = false, danger = false }) => (
    <TouchableOpacity 
      style={[
        styles.menuItem,
        !isLast && { borderBottomWidth: 1, borderBottomColor: theme.border }
      ]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.menuItemLeft}>
        <View style={[styles.menuItemIconContainer, { backgroundColor: `${danger ? theme.error : theme.primary}15` }]}>
          {React.cloneElement(icon, { 
            size: 20, 
            color: danger ? theme.error : theme.textSecondary 
          })}
        </View>
        <Text style={[styles.menuItemText, { color: danger ? theme.error : theme.text }]}>
          {title}
        </Text>
      </View>
      <View style={styles.menuItemRight}>
        {rightText && (
          <Text style={[styles.menuItemRightText, { color: theme.textSecondary }]}>
            {rightText}
          </Text>
        )}
        {rightComponent || <ChevronRight size={16} color={theme.textSecondary} />}
      </View>
    </TouchableOpacity>
  );

  const StatCard = ({ stat, index }) => (
    <View style={[styles.statCard, { backgroundColor: theme.surface }]}>
      <View style={[styles.statIconContainer, { backgroundColor: `${stat.color}15` }]}>
        <stat.icon size={20} color={stat.color} />
      </View>
      <Text style={[styles.statValue, { color: theme.text }]}>
        {stat.value}
      </Text>
      <Text style={[styles.statLabel, { color: theme.textSecondary }]}>
        {stat.label}
      </Text>
    </View>
  );

  const AchievementBadge = ({ achievement }) => (
    <View style={[
      styles.achievementBadge, 
      { 
        backgroundColor: achievement.earned ? `${achievement.color}15` : theme.surface,
        borderColor: achievement.earned ? achievement.color : theme.border,
        opacity: achievement.earned ? 1 : 0.6
      }
    ]}>
      <achievement.icon 
        size={16} 
        color={achievement.earned ? achievement.color : theme.textSecondary} 
      />
      <Text style={[
        styles.achievementText, 
        { color: achievement.earned ? achievement.color : theme.textSecondary }
      ]}>
        {achievement.title}
      </Text>
    </View>
  );

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  const headerTranslateY = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [0, -50],
    extrapolate: 'clamp',
  });

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Animated Header */}
      <Animated.View 
        style={[
          styles.animatedHeader,
          {
            opacity: headerOpacity,
            transform: [{ translateY: headerTranslateY }],
          }
        ]}
      >
        <View style={styles.headerBackground}>
          <View style={[styles.headerGradient, { 
            backgroundColor: `${theme.primary}08`,
          }]} />
          <View style={[styles.headerPattern, { opacity: theme.isDark ? 0.03 : 0.05 }]}>
            <View style={[styles.patternCircle, styles.circle1, { backgroundColor: theme.primary }]} />
            <View style={[styles.patternCircle, styles.circle2, { backgroundColor: theme.secondary }]} />
          </View>
        </View>
        
        <View style={styles.headerContent}>
          <View style={styles.profileSection}>
            <View style={[styles.avatarContainer, { shadowColor: theme.text }]}>
              <Image
                source={{ 
                  uri: user?.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=2' 
                }}
                style={styles.avatar}
              />
              <View style={[styles.onlineIndicator, { backgroundColor: '#32D74B', borderColor: theme.background }]} />
            </View>
            
            <View style={styles.profileInfo}>
              <View style={styles.nameContainer}>
                <Text style={[styles.name, { color: theme.text }]}>
                  {user?.name}
                </Text>
                <TouchableOpacity 
                  style={[styles.editButton, { backgroundColor: theme.surface }]}
                  onPress={handleEditProfile}
                  activeOpacity={0.7}
                >
                  <Edit3 size={14} color={theme.primary} />
                </TouchableOpacity>
              </View>
              <Text style={[styles.email, { color: theme.textSecondary }]}>
                {user?.email}
              </Text>
              <Text style={[styles.joinDate, { color: theme.textSecondary }]}>
                Member since {user?.createdAt ? new Date(user.createdAt).getFullYear() : '2024'}
              </Text>
            </View>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >
        {/* Spacer for animated header */}
        <View style={{ height: 180 }} />

        {/* Stats Grid */}
        <View style={styles.statsSection}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            Your Activity
          </Text>
          <View style={styles.statsGrid}>
            {profileStats.map((stat, index) => (
              <StatCard key={stat.label} stat={stat} index={index} />
            ))}
          </View>
        </View>

        {/* Achievements */}
        <View style={styles.achievementsSection}>
          <View style={styles.achievementsHeader}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              Achievements
            </Text>
            <View style={[styles.achievementsBadge, { backgroundColor: theme.primary }]}>
              <Award size={12} color={theme.background} />
              <Text style={[styles.achievementsBadgeText, { color: theme.background }]}>
                {achievements.filter(a => a.earned).length}/{achievements.length}
              </Text>
            </View>
          </View>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.achievementsList}
          >
            {achievements.map((achievement) => (
              <AchievementBadge key={achievement.id} achievement={achievement} />
            ))}
          </ScrollView>
        </View>

        {/* Menu Sections */}
        <MenuSection title="Content & Activity">
          <MenuItem
            icon={<Bookmark />}
            title="Saved Articles"
            onPress={() => {}}
            rightText={`${savedPosts.length} saved`}
          />
          <MenuItem
            icon={<History />}
            title="Reading History"
            onPress={() => {}}
            rightText="156 read"
          />
          <MenuItem
            icon={<Share2 />}
            title="Shared Content"
            onPress={() => {}}
            rightText="12 shared"
            isLast
          />
        </MenuSection>

        <MenuSection title="Preferences">
          <MenuItem
            icon={isDark ? <Moon /> : <Sun />}
            title="Appearance"
            onPress={toggleTheme}
            rightComponent={
              <View style={styles.themeToggleContainer}>
                <View style={[
                  styles.themeToggle,
                  { backgroundColor: isDark ? theme.primary : theme.border }
                ]}>
                  <View style={[
                    styles.themeToggleThumb,
                    { 
                      backgroundColor: theme.background,
                      transform: [{ translateX: isDark ? 16 : 2 }]
                    }
                  ]} />
                </View>
              </View>
            }
          />
          <MenuItem
            icon={<Bell />}
            title="Notifications"
            onPress={() => {}}
            rightText="All enabled"
          />
          <MenuItem
            icon={<Settings />}
            title="Account Settings"
            onPress={() => {}}
            isLast
          />
        </MenuSection>

        <MenuSection title="Support & Legal" style={{ marginBottom: 100 }}>
          <MenuItem
            icon={<LogOut />}
            title="Sign Out"
            onPress={handleSignOut}
            danger
            isLast
          />
        </MenuSection>
      </Animated.ScrollView>

      {/* Edit Profile Modal */}
      <Modal
        visible={isEditModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setIsEditModalVisible(false)}
      >
        <SafeAreaView style={[styles.modalContainer, { backgroundColor: theme.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: theme.border }]}>
            <TouchableOpacity 
              onPress={() => setIsEditModalVisible(false)}
              style={styles.modalCancelButton}
            >
              <Text style={[styles.modalCancelText, { color: theme.textSecondary }]}>
                Cancel
              </Text>
            </TouchableOpacity>
            
            <Text style={[styles.modalTitle, { color: theme.text }]}>
              Edit Profile
            </Text>
            
            <TouchableOpacity 
              onPress={handleSaveProfile}
              disabled={isUpdating}
              style={[
                styles.modalSaveButton,
                { backgroundColor: theme.primary, opacity: isUpdating ? 0.6 : 1 }
              ]}
            >
              <Text style={[styles.modalSaveText, { color: theme.background }]}>
                {isUpdating ? 'Saving...' : 'Save'}
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
            <View style={styles.modalAvatarSection}>
              <View style={styles.modalAvatarContainer}>
                <Image
                  source={{ 
                    uri: user?.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=2' 
                  }}
                  style={styles.modalAvatar}
                />
                <TouchableOpacity 
                  style={[styles.changeAvatarButton, { backgroundColor: theme.primary }]}
                  onPress={() => Alert.alert('Coming Soon', 'Avatar upload will be available in a future update')}
                >
                  <Edit3 size={16} color={theme.background} />
                </TouchableOpacity>
              </View>
              <Text style={[styles.changeAvatarText, { color: theme.textSecondary }]}>
                Tap to change profile photo
              </Text>
            </View>

            <View style={styles.modalForm}>
              <TextInput
                label="Full Name"
                value={editForm.name}
                onChangeText={(text) => setEditForm(prev => ({ ...prev, name: text }))}
                placeholder="Enter your full name"
                style={styles.modalInput}
              />

              <TextInput
                label="Email Address"
                value={editForm.email}
                onChangeText={(text) => setEditForm(prev => ({ ...prev, email: text }))}
                placeholder="Enter your email address"
                keyboardType="email-address"
                autoCapitalize="none"
                style={styles.modalInput}
              />

              <View style={[styles.infoCard, { backgroundColor: theme.surface }]}>
                <Text style={[styles.infoTitle, { color: theme.text }]}>
                  Profile Information
                </Text>
                <Text style={[styles.infoText, { color: theme.textSecondary }]}>
                  Your profile information is used to personalize your experience and help other users discover your content. Changes will be reflected across the platform.
                </Text>
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  animatedHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    height: 180,
  },
  headerBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    overflow: 'hidden',
  },
  headerGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  headerPattern: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  patternCircle: {
    position: 'absolute',
    borderRadius: 999,
  },
  circle1: {
    width: width * 0.6,
    height: width * 0.6,
    top: -width * 0.3,
    right: -width * 0.2,
  },
  circle2: {
    width: width * 0.4,
    height: width * 0.4,
    bottom: -width * 0.1,
    left: -width * 0.1,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 28,
    paddingTop: 60,
    justifyContent: 'center',
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 20,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 12,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 4,
  },
  profileInfo: {
    flex: 1,
  },
  nameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  name: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    marginRight: 12,
  },
  editButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  email: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  joinDate: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    opacity: 0.8,
  },
  scrollView: {
    flex: 1,
  },
  statsSection: {
    paddingHorizontal: 28,
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    marginBottom: 20,
    letterSpacing: -0.3,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 16,
  },
  statCard: {
    width: (width - 56 - 16) / 2,
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 6,
  },
  statIconContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    marginBottom: 4,
    letterSpacing: -0.5,
  },
  statLabel: {
    fontSize: 13,
    fontFamily: 'Inter-Medium',
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  achievementsSection: {
    paddingHorizontal: 28,
    marginBottom: 32,
  },
  achievementsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  achievementsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  achievementsBadgeText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    marginLeft: 6,
  },
  achievementsList: {
    paddingRight: 28,
  },
  achievementBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
    borderWidth: 1.5,
    marginRight: 12,
    minWidth: 140,
  },
  achievementText: {
    fontSize: 13,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
    letterSpacing: 0.2,
  },
  menuSection: {
    marginBottom: 24,
  },
  menuSectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    marginBottom: 16,
    paddingHorizontal: 28,
    letterSpacing: -0.2,
  },
  menuSectionContent: {
    marginHorizontal: 20,
    borderRadius: 20,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 4,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 18,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuItemIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  menuItemText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    letterSpacing: 0.1,
  },
  menuItemRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemRightText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginRight: 12,
    letterSpacing: 0.1,
  },
  themeToggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  themeToggleText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginRight: 12,
  },
  themeToggle: {
    width: 44,
    height: 24,
    borderRadius: 12,
    padding: 2,
    justifyContent: 'center',
  },
  themeToggleThumb: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  modalCancelButton: {
    paddingVertical: 8,
    paddingHorizontal: 4,
  },
  modalCancelText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    letterSpacing: -0.2,
  },
  modalSaveButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  modalSaveText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: 24,
  },
  modalAvatarSection: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  modalAvatarContainer: {
    position: 'relative',
    marginBottom: 12,
  },
  modalAvatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  changeAvatarButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  changeAvatarText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  modalForm: {
    paddingBottom: 40,
  },
  modalInput: {
    marginBottom: 24,
  },
  infoCard: {
    padding: 20,
    borderRadius: 16,
    marginTop: 24,
  },
  infoTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
    letterSpacing: 0.1,
  },
});