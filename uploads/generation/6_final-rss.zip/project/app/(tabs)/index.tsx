import React from 'react';
import { View, Text, StyleSheet, FlatList, SafeAreaView, RefreshControl, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useContent } from '@/contexts/ContentContext';
import { useAuth } from '@/contexts/AuthContext';
import { PostCard } from '@/components/PostCard';
import { LoadingSpinner } from '@/components/LoadingSpinner';

export default function HomeScreen() {
  const { theme } = useTheme();
  const { posts, isLoading, refreshFeed } = useContent();
  const { user } = useAuth();
  const router = useRouter();

  const handlePostPress = (postId: string) => {
    router.push(`/post-detail?id=${postId}`);
  };

  const renderPost = ({ item }) => (
    <PostCard 
      post={item} 
      onPress={() => handlePostPress(item.id)}
    />
  );

  const renderHeader = () => (
    <View style={[styles.header, { backgroundColor: theme.background }]}>
      <View style={styles.headerContent}>
        <View style={styles.userSection}>
          <View style={[styles.avatarContainer, { shadowColor: theme.text }]}>
            <Image 
              source={{ 
                uri: user?.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=120&h=120&dpr=2' 
              }}
              style={styles.userAvatar}
            />
            <View style={[styles.onlineIndicator, { backgroundColor: '#32D74B', borderColor: theme.background }]} />
          </View>
          <View style={styles.welcomeContainer}>
            <Text style={[styles.welcomeText, { color: theme.textSecondary }]}>
              Good {getTimeOfDay()},
            </Text>
            <Text style={[styles.userName, { color: theme.text }]}>
              {user?.name?.split(' ')[0] || 'User'}
            </Text>
            <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
              What's happening today?
            </Text>
          </View>
        </View>
        
        <View style={styles.headerActions}>
          <View style={[styles.notificationBadge, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <View style={[styles.notificationDot, { backgroundColor: theme.error }]} />
            <Text style={[styles.notificationCount, { color: theme.text }]}>3</Text>
          </View>
        </View>
      </View>
      
      <View style={[styles.gradientOverlay, { 
        background: `linear-gradient(135deg, ${theme.primary}15 0%, ${theme.secondary}08 100%)` 
      }]} />
    </View>
  );

  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 17) return 'afternoon';
    return 'evening';
  };

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Text style={[styles.emptyTitle, { color: theme.text }]}>
        No posts yet
      </Text>
      <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
        Subscribe to some content categories to see posts here
      </Text>
    </View>
  );

  if (isLoading && posts.length === 0) {
    return <LoadingSpinner />;
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <FlatList
        data={posts}
        renderItem={renderPost}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={refreshFeed}
            tintColor={theme.primary}
          />
        }
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContainer}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContainer: {
    paddingBottom: 16,
  },
  header: {
    paddingHorizontal: 28,
    paddingTop: 24,
    paddingBottom: 32,
    position: 'relative',
    overflow: 'hidden',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 2,
  },
  userSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 20,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  userAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 3,
  },
  welcomeContainer: {
    flex: 1,
  },
  welcomeText: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  userName: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    marginBottom: 2,
    lineHeight: 32,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    letterSpacing: 0.1,
    opacity: 0.8,
  },
  headerActions: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  notificationBadge: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    position: 'relative',
  },
  notificationDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  notificationCount: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  gradientOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1,
    borderRadius: 24,
    margin: 16,
    opacity: 0.6,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 64,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
});