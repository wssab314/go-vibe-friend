import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, SafeAreaView, TouchableOpacity, Dimensions, Animated, ScrollView } from 'react-native';
import { BlurView } from 'expo-blur';
import { useTheme } from '@/contexts/ThemeContext';
import { useContent } from '@/contexts/ContentContext';
import { CategoryCard } from '@/components/CategoryCard';
import { TextInput } from '@/components/TextInput';
import { Search as SearchIcon, TrendingUp, Sparkles, Filter, Grid3x3 as Grid3X3, List, Zap, Star, Award, Users } from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function SearchScreen() {
  const { theme } = useTheme();
  const { categories, toggleSubscription } = useContent();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [scrollY] = useState(new Animated.Value(0));

  const trendingTopics = [
    { name: 'AI Revolution', icon: Zap, color: '#FF6B6B', trending: '+125%' },
    { name: 'Market Analysis', icon: TrendingUp, color: '#4ECDC4', trending: '+89%' },
    { name: 'Mobile Development', icon: Sparkles, color: '#45B7D1', trending: '+67%' },
    { name: 'Health & Wellness', icon: Star, color: '#96CEB4', trending: '+45%' },
    { name: 'Climate Change', icon: Award, color: '#FFEAA7', trending: '+34%' },
    { name: 'Cryptocurrency', icon: Users, color: '#DDA0DD', trending: '+23%' },
  ];

  const filterOptions = [
    { id: 'all', label: 'All Categories', count: categories.length },
    { id: 'subscribed', label: 'Subscribed', count: categories.filter(c => c.subscribed).length },
    { id: 'trending', label: 'Trending', count: 4 },
    { id: 'new', label: 'New', count: 2 },
  ];

  const filteredCategories = categories.filter(category => {
    const matchesSearch = category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         category.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedFilter === 'subscribed') {
      return matchesSearch && category.subscribed;
    }
    
    return matchesSearch;
  });

  const renderTrendingItem = ({ item, index }) => (
    <TouchableOpacity 
      style={[styles.trendingItem, { backgroundColor: theme.surface }]}
      activeOpacity={0.8}
    >
      <View style={[styles.trendingIconContainer, { backgroundColor: `${item.color}15` }]}>
        <item.icon size={16} color={item.color} strokeWidth={2.5} />
      </View>
      <View style={styles.trendingContent}>
        <Text style={[styles.trendingText, { color: theme.text }]}>
          {item.name}
        </Text>
        <View style={styles.trendingMeta}>
          <View style={[styles.trendingBadge, { backgroundColor: `${item.color}20` }]}>
            <Text style={[styles.trendingPercentage, { color: item.color }]}>
              {item.trending}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderFilterChip = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.filterChip,
        {
          backgroundColor: selectedFilter === item.id ? theme.primary : theme.surface,
          borderColor: selectedFilter === item.id ? theme.primary : theme.border,
        }
      ]}
      onPress={() => setSelectedFilter(item.id)}
      activeOpacity={0.8}
    >
      <Text style={[
        styles.filterChipText,
        { color: selectedFilter === item.id ? theme.background : theme.text }
      ]}>
        {item.label}
      </Text>
      {item.count > 0 && (
        <View style={[
          styles.filterChipBadge,
          { backgroundColor: selectedFilter === item.id ? `${theme.background}25` : `${theme.primary}15` }
        ]}>
          <Text style={[
            styles.filterChipBadgeText,
            { color: selectedFilter === item.id ? theme.background : theme.primary }
          ]}>
            {item.count}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );

  const renderCategory = ({ item, index }) => (
    <View style={[
      styles.categoryWrapper,
      viewMode === 'grid' && styles.categoryGridWrapper
    ]}>
      <CategoryCard 
        category={item} 
        onPress={() => toggleSubscription(item.id)}
        viewMode={viewMode}
      />
    </View>
  );

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [1, 0.9],
    extrapolate: 'clamp',
  });

  const headerTranslateY = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [0, -10],
    extrapolate: 'clamp',
  });

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Animated Header */}
      <Animated.View 
        style={[
          styles.header,
          {
            opacity: headerOpacity,
            transform: [{ translateY: headerTranslateY }],
          }
        ]}
      >
        {/* Frosted Glass Background */}
        <BlurView
          intensity={theme.isDark ? 120 : 100}
          tint={theme.isDark ? 'dark' : 'light'}
          style={styles.blurBackground}
        >
          {/* Additional Blur Layer for Deeper Effect */}
          <BlurView
            intensity={theme.isDark ? 60 : 40}
            tint={theme.isDark ? 'dark' : 'light'}
            style={styles.secondaryBlur}
          />
          
          {/* Gradient Overlay */}
          <View style={[
            styles.gradientOverlay,
            {
              backgroundColor: theme.isDark 
                ? 'rgba(0, 0, 0, 0.6)' 
                : 'rgba(255, 255, 255, 0.5)',
            }
          ]} />
          
          {/* Background Pattern */}
          <View style={[styles.headerPattern, { opacity: theme.isDark ? 0.08 : 0.12 }]}>
            <View style={[styles.patternCircle, styles.circle1, { backgroundColor: theme.primary }]} />
            <View style={[styles.patternCircle, styles.circle2, { backgroundColor: theme.secondary }]} />
            <View style={[styles.patternCircle, styles.circle3, { backgroundColor: theme.accent }]} />
          </View>
          
          {/* Subtle Noise Texture */}
          <View style={[
            styles.noiseTexture,
            {
              backgroundColor: theme.isDark 
                ? 'rgba(255, 255, 255, 0.04)' 
                : 'rgba(0, 0, 0, 0.06)',
            }
          ]} />
          
          {/* Deep Frost Effect */}
          <View style={[
            styles.frostEffect,
            {
              backgroundColor: theme.isDark 
                ? 'rgba(255, 255, 255, 0.01)' 
                : 'rgba(255, 255, 255, 0.8)',
            }
          ]} />
        </BlurView>

        <View style={styles.headerContent}>
          <View style={styles.titleSection}>
            <View style={styles.titleContainer}>
              <Text style={[styles.title, { color: theme.text }]}>
                Discover Content
              </Text>
              <View style={[styles.titleAccent, { backgroundColor: theme.primary }]}>
                <Sparkles size={16} color={theme.background} />
              </View>
            </View>
            <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
              Explore trending topics and find your next favorite read
            </Text>
          </View>

          {/* Search Bar */}
          <BlurView
            intensity={theme.isDark ? 80 : 60}
            tint={theme.isDark ? 'dark' : 'light'}
            style={[
              styles.searchContainer,
              {
                backgroundColor: theme.isDark 
                  ? 'rgba(255, 255, 255, 0.12)' 
                  : 'rgba(255, 255, 255, 0.8)',
                borderWidth: 1,
                borderColor: theme.isDark 
                  ? 'rgba(255, 255, 255, 0.15)' 
                  : 'rgba(255, 255, 255, 0.5)',
              }
            ]}
          >
            {/* Additional Search Bar Blur Layer */}
            <BlurView
              intensity={theme.isDark ? 30 : 20}
              tint={theme.isDark ? 'dark' : 'light'}
              style={styles.searchBlurLayer}
            />
            <View style={styles.searchContent}>
              <SearchIcon size={20} color={theme.textSecondary} />
              <TextInput
                placeholder="Search categories, topics, or authors..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                style={styles.searchInput}
                containerStyle={styles.searchInputContainer}
              />
              <TouchableOpacity style={[styles.filterButton, { backgroundColor: theme.primary }]}>
                <Filter size={16} color={theme.background} />
              </TouchableOpacity>
            </View>
          </BlurView>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >
        {/* Spacer for header */}
        <View style={{ height: 180 }} />

        {/* Trending Topics */}
        <View style={styles.trendingSection}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleContainer}>
              <TrendingUp size={20} color={theme.primary} />
              <Text style={[styles.sectionTitle, { color: theme.text }]}>
                Trending Now
              </Text>
            </View>
            <View style={[styles.liveBadge, { backgroundColor: '#FF4757' }]}>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>LIVE</Text>
            </View>
          </View>
          
          <FlatList
            data={trendingTopics}
            renderItem={renderTrendingItem}
            keyExtractor={(item) => item.name}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.trendingList}
          />
        </View>

        {/* Filter Chips */}
        <View style={styles.filtersSection}>
          <FlatList
            data={filterOptions}
            renderItem={renderFilterChip}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filtersList}
          />
        </View>

        {/* Categories Header */}
        <View style={styles.categoriesHeader}>
          <View style={styles.categoriesHeaderLeft}>
            <Text style={[styles.categoriesTitle, { color: theme.text }]}>
              Categories
            </Text>
            <View style={[styles.categoriesCount, { backgroundColor: theme.surface }]}>
              <Text style={[styles.categoriesCountText, { color: theme.text }]}>
                {filteredCategories.length}
              </Text>
            </View>
          </View>
          
          <View style={styles.viewModeContainer}>
            <TouchableOpacity
              style={[
                styles.viewModeButton,
                viewMode === 'list' && { backgroundColor: theme.primary }
              ]}
              onPress={() => setViewMode('list')}
            >
              <List 
                size={16} 
                color={viewMode === 'list' ? theme.background : theme.textSecondary} 
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.viewModeButton,
                viewMode === 'grid' && { backgroundColor: theme.primary }
              ]}
              onPress={() => setViewMode('grid')}
            >
              <Grid3X3 
                size={16} 
                color={viewMode === 'grid' ? theme.background : theme.textSecondary} 
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Categories List */}
        <View style={styles.categoriesContainer}>
          {viewMode === 'grid' ? (
            <View style={styles.categoriesGrid}>
              {filteredCategories.map((category, index) => (
                <View key={category.id} style={styles.categoryGridItem}>
                  <CategoryCard 
                    category={category} 
                    onPress={() => toggleSubscription(category.id)}
                    viewMode="grid"
                  />
                </View>
              ))}
            </View>
          ) : (
            <FlatList
              data={filteredCategories}
              renderItem={renderCategory}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              contentContainerStyle={styles.categoriesList}
            />
          )}
        </View>

        {/* Bottom Spacer */}
        <View style={{ height: 100 }} />
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    height: 180,
    overflow: 'hidden',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  blurBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  secondaryBlur: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  gradientOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  noiseTexture: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    opacity: 0.8,
  },
  frostEffect: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    opacity: 0.3,
  },
  headerPattern: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  patternCircle: {
    position: 'absolute',
    borderRadius: 999,
  },
  circle1: {
    width: width * 0.5,
    height: width * 0.5,
    top: -width * 0.25,
    right: -width * 0.15,
  },
  circle2: {
    width: width * 0.3,
    height: width * 0.3,
    bottom: -width * 0.1,
    left: -width * 0.1,
  },
  circle3: {
    width: width * 0.2,
    height: width * 0.2,
    top: 60,
    right: width * 0.3,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 28,
    paddingTop: 60,
    justifyContent: 'flex-start',
    paddingBottom: 16,
    zIndex: 2,
  },
  titleSection: {
    marginBottom: 32,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    marginRight: 12,
  },
  titleAccent: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  subtitle: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    lineHeight: 22,
    letterSpacing: 0.2,
  },
  searchContainer: {
    borderRadius: 20,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 16,
    overflow: 'hidden',
  },
  searchBlurLayer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  searchContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    zIndex: 2,
  },
  searchInputContainer: {
    marginBottom: 0,
    flex: 1,
    marginHorizontal: 12,
  },
  searchInput: {
    marginBottom: 0,
  },
  filterButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollContainer: {
    flex: 1,
  },
  trendingSection: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 28,
    marginBottom: 20,
  },
  sectionTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    marginLeft: 8,
    letterSpacing: -0.3,
  },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#FFFFFF',
    marginRight: 4,
  },
  liveText: {
    fontSize: 10,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  trendingList: {
    paddingHorizontal: 28,
  },
  trendingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    borderRadius: 16,
    minWidth: 180,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
  },
  trendingIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  trendingContent: {
    flex: 1,
  },
  trendingText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
    letterSpacing: 0.1,
  },
  trendingMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  trendingBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  trendingPercentage: {
    fontSize: 11,
    fontFamily: 'Inter-Bold',
    letterSpacing: 0.2,
  },
  filtersSection: {
    marginBottom: 32,
  },
  filtersList: {
    paddingHorizontal: 28,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
    marginRight: 12,
  },
  filterChipText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    letterSpacing: 0.1,
  },
  filterChipBadge: {
    marginLeft: 8,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
  },
  filterChipBadgeText: {
    fontSize: 11,
    fontFamily: 'Inter-Bold',
  },
  categoriesHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 28,
    marginBottom: 20,
  },
  categoriesHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoriesTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.3,
    marginRight: 12,
  },
  categoriesCount: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoriesCountText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
  },
  viewModeContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: 12,
    padding: 2,
  },
  viewModeButton: {
    width: 32,
    height: 32,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoriesContainer: {
    paddingHorizontal: 28,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  categoryGridItem: {
    width: (width - 56 - 16) / 2,
    marginBottom: 16,
  },
  categoriesList: {
    paddingBottom: 16,
  },
  categoryWrapper: {
    marginBottom: 12,
  },
  categoryGridWrapper: {
    marginBottom: 16,
  },
});