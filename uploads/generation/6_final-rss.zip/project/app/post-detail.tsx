import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, TouchableOpacity, Image, TextInput, KeyboardAvoidingView, Platform, Animated } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useContent } from '@/contexts/ContentContext';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Heart, Bookmark, Share, MessageCircle, Send, MoveHorizontal as MoreHorizontal, Eye, Clock } from 'lucide-react-native';

interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  createdAt: Date;
  likes: number;
  isLiked: boolean;
}

const mockComments: Comment[] = [
  {
    id: '1',
    author: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&dpr=1',
    content: 'This is such an insightful article! I\'ve been struggling with digital wellness lately and these tips are exactly what I needed.',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    likes: 12,
    isLiked: false,
  },
  {
    id: '2',
    author: 'Mike Chen',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&dpr=1',
    content: 'Great perspective on mindfulness in the digital age. The part about intentional technology use really resonated with me.',
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    likes: 8,
    isLiked: true,
  },
  {
    id: '3',
    author: 'Emma Rodriguez',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&dpr=1',
    content: 'I\'ve implemented some of these practices and they\'ve made a huge difference in my daily routine. Thanks for sharing!',
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    likes: 15,
    isLiked: false,
  },
];

export default function PostDetailScreen() {
  const { theme } = useTheme();
  const { posts, toggleLike, toggleSave } = useContent();
  const { user } = useAuth();
  const router = useRouter();
  const { id } = useLocalSearchParams();

  const [comments, setComments] = useState<Comment[]>(mockComments);
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [scrollY] = useState(new Animated.Value(0));

  const post = posts.find(p => p.id === id);

  if (!post) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
        <View style={styles.errorContainer}>
          <Text style={[styles.errorText, { color: theme.text }]}>
            Post not found
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    
    const diffInWeeks = Math.floor(diffInDays / 7);
    return `${diffInWeeks}w ago`;
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const handleSubmitComment = async () => {
    if (!newComment.trim() || isSubmitting) return;

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));

    const comment: Comment = {
      id: Date.now().toString(),
      author: user?.name || 'Anonymous',
      avatar: user?.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&dpr=1',
      content: newComment.trim(),
      createdAt: new Date(),
      likes: 0,
      isLiked: false,
    };

    setComments(prev => [comment, ...prev]);
    setNewComment('');
    setIsSubmitting(false);
  };

  const toggleCommentLike = (commentId: string) => {
    setComments(prev => 
      prev.map(comment => 
        comment.id === commentId 
          ? { 
              ...comment, 
              isLiked: !comment.isLiked,
              likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1
            }
          : comment
      )
    );
  };

  const ActionButton = ({ 
    onPress, 
    icon, 
    count, 
    color = theme.textSecondary, 
    activeColor, 
    isActive = false,
    hoverColor = 'rgba(29, 155, 240, 0.08)'
  }: {
    onPress: () => void;
    icon: React.ReactNode;
    count?: string | number;
    color?: string;
    activeColor?: string;
    isActive?: boolean;
    hoverColor?: string;
  }) => {
    const [isPressed, setIsPressed] = React.useState(false);
    
    return (
      <TouchableOpacity 
        style={styles.actionButton}
        onPress={onPress}
        onPressIn={() => setIsPressed(true)}
        onPressOut={() => setIsPressed(false)}
        activeOpacity={0.9}
      >
        <View style={[
          styles.actionIconContainer,
          isPressed && { backgroundColor: hoverColor },
          isActive && activeColor && { backgroundColor: `${activeColor}12` }
        ]}>
          {icon}
        </View>
        {count !== undefined && (
          <Text style={[
            styles.actionText, 
            { color: isActive && activeColor ? activeColor : color }
          ]}>
            {typeof count === 'number' ? formatNumber(count) : count}
          </Text>
        )}
      </TouchableOpacity>
    );
  };

  const CommentItem = ({ comment }: { comment: Comment }) => (
    <View style={[styles.commentItem, { borderBottomColor: theme.border }]}>
      <View style={styles.commentAvatarContainer}>
        <Image source={{ uri: comment.avatar }} style={styles.commentAvatar} />
      </View>
      <View style={styles.commentContent}>
        <View style={styles.commentHeader}>
          <Text style={[styles.commentAuthor, { color: theme.text }]}>
            {comment.author}
          </Text>
          <View style={[styles.commentDot, { backgroundColor: theme.textSecondary }]} />
          <Text style={[styles.commentTime, { color: theme.textSecondary }]}>
            {formatTimeAgo(comment.createdAt)}
          </Text>
        </View>
        <Text style={[styles.commentText, { color: theme.text }]}>
          {comment.content}
        </Text>
        <View style={styles.commentActions}>
          <TouchableOpacity 
            style={styles.commentAction}
            onPress={() => toggleCommentLike(comment.id)}
          >
            <Heart 
              size={14} 
              color={comment.isLiked ? '#F91880' : theme.textSecondary}
              fill={comment.isLiked ? '#F91880' : 'none'}
            />
            <Text style={[styles.commentActionText, { 
              color: comment.isLiked ? '#F91880' : theme.textSecondary 
            }]}>
              {comment.likes}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.commentAction}>
            <Text style={[styles.commentActionText, { color: theme.textSecondary }]}>
              Reply
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      <TouchableOpacity style={styles.commentMore}>
        <MoreHorizontal size={16} color={theme.textSecondary} />
      </TouchableOpacity>
    </View>
  );

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [0, 1],
    extrapolate: 'clamp',
  });

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <KeyboardAvoidingView 
        style={styles.keyboardAvoid}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Animated Header */}
        <Animated.View style={[
          styles.header, 
          { 
            backgroundColor: theme.background,
            borderBottomColor: theme.border,
            borderBottomWidth: headerOpacity.interpolate({
              inputRange: [0, 1],
              outputRange: [0, 1],
            }),
          }
        ]}>
          <TouchableOpacity 
            style={[styles.headerButton, { backgroundColor: theme.surface }]}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={theme.text} />
          </TouchableOpacity>
          
          <Animated.Text style={[
            styles.headerTitle, 
            { color: theme.text, opacity: headerOpacity }
          ]}>
            {post.title.length > 30 ? `${post.title.substring(0, 30)}...` : post.title}
          </Animated.Text>
          
          <View style={{ width: 40 }} />
        </Animated.View>

        <Animated.ScrollView 
          style={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: scrollY } } }],
            { useNativeDriver: false }
          )}
          scrollEventThrottle={16}
        >
          {/* Hero Section */}
          <View style={[styles.heroSection, { backgroundColor: theme.surface }]}>
            <View style={styles.authorSection}>
              <View style={styles.authorInfo}>
                <Image 
                  source={{ uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=48&h=48&dpr=2' }}
                  style={styles.authorAvatar}
                />
                <View style={styles.authorDetails}>
                  <Text style={[styles.authorName, { color: theme.text }]}>
                    {post.author}
                  </Text>
                  <View style={styles.authorMeta}>
                    <Clock size={12} color={theme.textSecondary} />
                    <Text style={[styles.authorMetaText, { color: theme.textSecondary }]}>
                      {formatTimeAgo(post.createdAt)}
                    </Text>
                    <View style={[styles.metaDot, { backgroundColor: theme.textSecondary }]} />
                    <Eye size={12} color={theme.textSecondary} />
                    <Text style={[styles.authorMetaText, { color: theme.textSecondary }]}>
                      {post.readTime}
                    </Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity style={[styles.followButton, { backgroundColor: theme.primary }]}>
                <Text style={[styles.followButtonText, { color: theme.background }]}>
                  Follow
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.postTitle, { color: theme.text }]}>
              {post.title}
            </Text>
          </View>

          {/* Article Content */}
          <View style={[styles.contentSection, { backgroundColor: theme.background }]}>
            <Text style={[styles.articleContent, { color: theme.text }]}>
              {post.content}
            </Text>

            {/* Engagement Actions */}
            <View style={[styles.engagementSection, { backgroundColor: theme.surface }]}>
              <View style={styles.engagementActions}>
                <ActionButton
                  onPress={() => toggleLike(post.id)}
                  icon={
                    <Heart 
                      size={20} 
                      color={post.isLiked ? '#F91880' : theme.textSecondary}
                      fill={post.isLiked ? '#F91880' : 'none'}
                    />
                  }
                  count={post.likes}
                  isActive={post.isLiked}
                  activeColor="#F91880"
                  hoverColor="rgba(249, 24, 128, 0.08)"
                />

                <ActionButton
                  onPress={() => {}}
                  icon={<MessageCircle size={20} color={theme.textSecondary} />}
                  count={comments.length}
                  hoverColor="rgba(29, 155, 240, 0.08)"
                />

                <ActionButton
                  onPress={() => toggleSave(post.id)}
                  icon={
                    <Bookmark 
                      size={20} 
                      color={post.isSaved ? theme.primary : theme.textSecondary}
                      fill={post.isSaved ? theme.primary : 'none'}
                    />
                  }
                  isActive={post.isSaved}
                  activeColor={theme.primary}
                  hoverColor="rgba(29, 155, 240, 0.08)"
                />

                <ActionButton
                  onPress={() => {}}
                  icon={<Share size={20} color={theme.textSecondary} />}
                  hoverColor="rgba(29, 155, 240, 0.08)"
                />
              </View>
            </View>
          </View>

          {/* Comments Section */}
          <View style={[styles.commentsSection, { backgroundColor: theme.background }]}>
            <View style={styles.commentsSectionHeader}>
              <Text style={[styles.commentsTitle, { color: theme.text }]}>
                Comments
              </Text>
              <View style={[styles.commentsCount, { backgroundColor: theme.surface }]}>
                <Text style={[styles.commentsCountText, { color: theme.text }]}>
                  {comments.length}
                </Text>
              </View>
            </View>

            {/* Comment Input */}
            <View style={[styles.commentInputContainer, { 
              backgroundColor: theme.surface, 
              borderColor: theme.border 
            }]}>
              <Image 
                source={{ uri: user?.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&dpr=1' }}
                style={styles.inputAvatar}
              />
              <TextInput
                style={[styles.commentInput, { color: theme.text }]}
                placeholder="Share your thoughts..."
                placeholderTextColor={theme.textSecondary}
                value={newComment}
                onChangeText={setNewComment}
                multiline
                maxLength={500}
                selectionColor={theme.primary}
              />
              <TouchableOpacity 
                style={[
                  styles.sendButton,
                  { 
                    backgroundColor: newComment.trim() ? theme.primary : theme.border,
                    opacity: isSubmitting ? 0.6 : 1
                  }
                ]}
                onPress={handleSubmitComment}
                disabled={!newComment.trim() || isSubmitting}
              >
                <Send 
                  size={16} 
                  color={newComment.trim() ? theme.background : theme.textSecondary} 
                />
              </TouchableOpacity>
            </View>

            {/* Comments List */}
            <View style={styles.commentsList}>
              {comments.map((comment) => (
                <CommentItem key={comment.id} comment={comment} />
              ))}
            </View>
          </View>
        </Animated.ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardAvoid: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
    zIndex: 100,
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    flex: 1,
    textAlign: 'center',
    marginHorizontal: 16,
  },
  scrollContainer: {
    flex: 1,
  },
  heroSection: {
    paddingHorizontal: 24,
    paddingVertical: 32,
    marginBottom: 2,
  },
  authorSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  authorInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  authorAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 16,
  },
  authorDetails: {
    flex: 1,
  },
  authorName: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  authorMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  authorMetaText: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
    marginRight: 8,
  },
  metaDot: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    marginRight: 8,
  },
  followButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
  },
  followButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  postTitle: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    lineHeight: 36,
    marginBottom: 20,
    letterSpacing: -0.5,
  },
  articleStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 24,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 13,
    fontFamily: 'Inter-Medium',
    marginLeft: 6,
  },
  contentSection: {
    paddingHorizontal: 24,
    paddingVertical: 32,
    marginBottom: 2,
  },
  articleContent: {
    fontSize: 17,
    fontFamily: 'Inter-Regular',
    lineHeight: 28,
    marginBottom: 32,
    letterSpacing: 0.2,
  },
  engagementSection: {
    borderRadius: 16,
    padding: 20,
  },
  engagementActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: 64,
  },
  actionIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    minWidth: 20,
  },
  commentsSection: {
    paddingHorizontal: 24,
    paddingVertical: 32,
  },
  commentsSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  commentsTitle: {
    fontSize: 22,
    fontFamily: 'Poppins-Bold',
  },
  commentsCount: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  commentsCountText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  commentInputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 32,
  },
  inputAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 16,
    marginTop: 4,
  },
  commentInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    minHeight: 44,
    maxHeight: 120,
    textAlignVertical: 'top',
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
    marginTop: 2,
  },
  commentsList: {
    gap: 0,
  },
  commentItem: {
    flexDirection: 'row',
    paddingVertical: 20,
    borderBottomWidth: 1,
  },
  commentAvatarContainer: {
    marginRight: 16,
  },
  commentAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  commentContent: {
    flex: 1,
  },
  commentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  commentAuthor: {
    fontSize: 15,
    fontFamily: 'Inter-Bold',
    marginRight: 8,
  },
  commentDot: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    marginRight: 8,
  },
  commentTime: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
  },
  commentText: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    lineHeight: 22,
    marginBottom: 12,
    letterSpacing: 0.1,
  },
  commentActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  commentAction: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  commentActionText: {
    fontSize: 13,
    fontFamily: 'Inter-Medium',
    marginLeft: 4,
  },
  commentMore: {
    padding: 8,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    padding: 24,
  },
});