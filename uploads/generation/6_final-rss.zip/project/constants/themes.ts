import { Theme } from '@/types';

export const lightTheme: Theme = {
  background: '#FFFFFF',
  surface: '#F7F9FA',
  text: '#0F0F0F',
  textSecondary: '#536471',
  border: '#EFF3F4',
  primary: '#007AFF',
  secondary: '#5856D6',
  accent: '#FF9500',
  success: '#34C759',
  warning: '#FF9500',
  error: '#FF3B30',
};

export const darkTheme: Theme = {
  background: '#000000',
  surface: '#16181C',
  text: '#F5F5F5',
  textSecondary: '#71767B',
  border: '#2F3336',
  primary: '#0A84FF',
  secondary: '#5E5CE6',
  accent: '#FF9F0A',
  success: '#32D74B',
  warning: '#FF9F0A',
  error: '#FF453A',
};